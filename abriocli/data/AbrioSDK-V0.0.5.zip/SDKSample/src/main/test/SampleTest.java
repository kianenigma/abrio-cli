import backend.EventPacket;
import ir.abrio.dev.protocol.AbrioMessages;
import ir.abrio.dev.protocol.AbrioProtocol;
import testbench.TestBench;
import testbench.TesterActor;

import java.rmi.NoSuchObjectException;

/**
 * this class test component
 */
public class SampleTest {
    public static void main(String[] args) throws InterruptedException, NoSuchObjectException {
        System.out.print("Test Running...");
        TestBench testBench = new TestBench<SampleComponent>(SampleComponent.class);
        TesterActor tester = testBench.createTester();
        tester.pushMessage(AbrioMessages.basicEvent("hi","2"));
        EventPacket eventPacket = tester.pullMessage();
        assert eventPacket.msg().getEventType() == AbrioProtocol.EventWrapper.EventType.BasicEvent;
        assert eventPacket.msg().getBasicEvent().getBody().equals("4");
        testBench.done();
    }
}
