/**
 *       _    ____  ____  ___ ___         ____ ___  __  __
 *      / \  | __ )|  _ \|_ _/ _ \       / ___/ _ \|  \/  |
 *     / _ \ |  _ \| |_) || | | | |     | |  | | | | |\/| |
 *    / ___ \| |_) |  _ < | | |_| |  _  | |__| |_| | |  | |
 *   /_/   \_\____/|_| \_\___\___/  (_)  \____\___/|_|  |_|
 *
 *
 * Abrio Main Component Class. See Online Docs, on inline comments for more info on how to override and implement this
 * Class.
 *
 *
 * Copyright © 2016 by Abrio Engine Team
 * All rights reserved. This code or any portion thereof
 * may not be reproduced or used in any manner whatsoever
 * except for being uplaoded into Abrio Server.
 *
 */

import akka.japi.Option;
import ir.abrio.dev.protocol.AbrioMessages;
import ir.abrio.dev.protocol.AbrioProtocol;
import ir.abrio.dev.sdk.AbrioComponent;

import java.io.IOException;

/**
 * main Component Class, your Logic will go here
 */
public class SampleComponent extends AbrioComponent {
    /**
     * Nothing specific for you here, move to the next method.
     * @param projectId
     * @throws IOException
     */
    public SampleComponent(String projectId) throws IOException {
        super(projectId);
    }

    /**
     * this function will get called every time message is received at your server!
     * @param message received message
     * @param context Context object contain state of incoming event
     */
    @Override
    public void receive(AbrioProtocol.EventWrapper message, Context context) {
        // Create Event Object.
        AbrioProtocol.BasicEvent basicEventMessage = message.getBasicEvent();
        System.out.println("I'm persisted multiply2 #"+id()+" and I've just received a message: \nTitle:"+basicEventMessage.getTitle()+"\nBody:"+basicEventMessage.getBody());

        // Send the Multiply two of received message as response to client.
        context.send(AbrioMessages.basicEvent(
                basicEventMessage.getTitle(),
                String.valueOf(Integer.parseInt(basicEventMessage.getBody())*2)));

        // Use any faction from your own code, or 3rd party library
        SomeOtherFunction();
    }

    /**
     * this fucntion gets called every time a new user is connected
     * @param context Context object contain state of incoming event
     */
    @Override
    public void connectionEstablished(Context context) {
        System.out.println("I'm multiply2 and " + context + " has connected to me");
    }

    /**
     * this function gets called every time a user disconnects.
     * @param context Context object contain state of incoming event
     */
    @Override
    public void connectionClosed(Context context) {
        System.out.println("I'm multiply2 and " + context + " has disconnected from me");
    }

    /**
     * feel free to write more functions, or even add separate classes
     */
    public void SomeOtherFunction() {
        // do some coding here
        // Use AbrioStorage for accession remote database
        // Use AbrioMemory for persistent memory data structure
        // and ..

        // TODO: 7/1/16 Add Examples for using AbrioMemory and AbrioStorage

    }
}
