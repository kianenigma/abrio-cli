package backend;

import akka.actor.ActorRef;

/**
 * Object used to subscribe client to channel
 */
public class SubscribeSession {
    public SubscribeSession(ActorRef clientSession){}
}
