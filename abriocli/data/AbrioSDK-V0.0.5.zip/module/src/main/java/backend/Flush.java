package backend;

/**
 * Object used to Flush via persistent data manager
 */
public class Flush {
}
