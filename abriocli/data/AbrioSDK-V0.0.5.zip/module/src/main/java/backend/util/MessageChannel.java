package backend.util;

import akka.actor.UntypedActor;

public class MessageChannel extends UntypedActor{
    public void onReceive(Object message) throws Exception {

    }
}
