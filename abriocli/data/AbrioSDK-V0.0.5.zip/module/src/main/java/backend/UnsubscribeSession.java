package backend;

import akka.actor.ActorRef;

/**
 * Object used to unsubscribe client to channel
 */
public class UnsubscribeSession {
    public UnsubscribeSession(ActorRef clientSession){}
}
