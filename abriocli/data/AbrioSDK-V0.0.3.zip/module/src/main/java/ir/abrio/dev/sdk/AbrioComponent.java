package ir.abrio.dev.sdk;

import akka.actor.ActorRef;
import akka.actor.Props;
import akka.actor.UntypedActor;
import backend.EventPacket;
import backend.SubscribeSession;
import backend.client.ClientSession;
import backend.util.MessageChannel;
import ir.abrio.dev.protocol.AbrioProtocol;

/**
 * AbrioLogic is main abstract class.
 * Implement this class
 */
public abstract class AbrioComponent extends UntypedActor {

    public AbrioComponent(){
        System.out.println("Hi I am abrio component. I am created.");
    }

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof EventPacket){
            if ( ((EventPacket) message).msg().getTitle().equals("client_up")) {
                connectionEstablished(
                        new Context(getSender(),((EventPacket) message).session())
                );
            }
            else if ( ((EventPacket) message).msg().getTitle().equals("client_down")) {
                connectionClosed(
                        new Context(getSender() , ((EventPacket) message).session())
                );
            }
            else {
                receive(
                        ((EventPacket) message).msg(),
                        new Context(getSender(), ((EventPacket) message).session())
                );
            }
        }
        else {
            // todo throw exception
            System.out.println("Invalid message: "+message.getClass().getName());
        }
    }

    protected ActorRef createChannel(Context context){
        return context().actorOf(Props.create(MessageChannel.class));
    }

    protected void subscribeTo(ActorRef channel,ClientSession client){
        channel.tell(new SubscribeSession(client.self()),self());
    }

    /**
     * This function will be called each time a message receive
     * @param message received message
     */
    abstract public void receive(AbrioProtocol.BasicEvent message,Context context);

    abstract public void connectionEstablished(Context context) ;

    abstract public void connectionClosed(Context context) ;

    /**
     * @return id of component
     */
    abstract public Integer id();

    protected class Context{
        private ActorRef sender;
        private ClientSession session;
        public Context(ActorRef sender,ClientSession session){
            this.sender = sender;
            this.session = session;
        }
        /**
         * DO NOT override this function unless you know exactly what are you doing
         * @param message this message will be send to client
         */
        public void send(AbrioProtocol.BasicEvent message){
            sender.tell(new EventPacket(message,session,id()),getSelf());
        }

        public ClientSession getSession() {
            return session;
        }
    }
}
