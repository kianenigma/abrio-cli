package ir.abrio.dev.sdk;

import akka.actor.UntypedActor;
import ir.abrio.dev.protocol.AbrioProtocol;

/**
 * AbrioLogic is main abstract class.
 * Implement this class
 */
public abstract class AbrioLogic extends UntypedActor {

    public AbrioLogic(){
        System.out.println("Hi I am abrio logic. I am created.");
    }
    /**
     * DO NOT override this function unless you know exactly what are you doing
     * @param message this message will be send to client
     */
    protected void send(String message){

    }

    @Override
    public void onReceive(Object message) throws Exception {
        if (message instanceof AbrioProtocol.BasicEvent) {
            receive((AbrioProtocol.BasicEvent) message);
        }
        else {
            // todo throw exception
            System.out.println("Invalid message");
        }
    }

    /**
     * This function will be called each time a message receive
     * @param message received message
     */
    abstract public void receive(AbrioProtocol.BasicEvent message);

    /**
     * This function will be called for each user that connect to server
     */
    abstract public void onConnect();
}
