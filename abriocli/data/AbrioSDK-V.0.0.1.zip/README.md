# AbrIO Client SDK App
  Sdk used By Developers to create custom logic for their apps.



## CLI configurations
  to test the cli tool :

  + move to cli directory and create a virtual env
  ```
  cd cli
  virtualenv venv
  . venv/bin/activate
  ```

  + install AbrIO CLI locally using
  ```
  pip install --editable .
  ```

Abrio CLI is now installed. 
