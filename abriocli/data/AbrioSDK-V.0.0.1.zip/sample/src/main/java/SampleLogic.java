
import ir.abrio.dev.protocol.AbrioProtocol;
import ir.abrio.dev.sdk.AbrioLogic;


public class SampleLogic extends AbrioLogic {
    @Override
    public void receive(AbrioProtocol.BasicEvent message) {
        System.out.println("I'm SampleLogic and I've just received a message: \nTitle:"+message.getTitle()+"\nBody:"+message.getBody());
    }

    @Override
    public void onConnect() {
        System.out.println("I'm SampleLogic and a client just connected to me");
    }
}
