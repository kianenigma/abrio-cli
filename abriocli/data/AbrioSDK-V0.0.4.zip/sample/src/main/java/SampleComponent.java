
import ir.abrio.dev.protocol.AbrioProtocol;
import ir.abrio.dev.sdk.AbrioComponent;


public class SampleComponent extends AbrioComponent {

    @Override
    public void receive(AbrioProtocol.BasicEvent message, Context context) {
        System.out.println("I'm multiply3 #"+id()
                +" and I've just received a message: \nTitle:"+message.getTitle()+"\nBody:"+message.getBody());

        AbrioProtocol.BasicEvent.Builder acknowledgeEvent = AbrioProtocol.BasicEvent.newBuilder();
        acknowledgeEvent.setTitle(message.getTitle());
        acknowledgeEvent.setBody(String.valueOf(Integer.parseInt(message.getBody())*3));
        context.send(acknowledgeEvent.build());
    }

    @Override
    public void connectionEstablished(Context context) {
        System.out.println("I'm multiply3 and " + context + " has connected to me");
    }

    @Override
    public void connectionClosed(Context context) {
        System.out.println("I'm multiply3 and " + context + " has disconnected from me");
    }


    @Override
    public Integer id() {
        return 2 ;
    }
}
