package backend;

/**
 * Created by Kian on 4/29/16.
 */
public class Update {
    private String key;
    private String payload;
    public Update(String Key, String Payload){
        this.key = Key;
        this.payload = Payload;
    }

    public String key(){ return key ; }
    public String payload() { return  payload ;}
}
