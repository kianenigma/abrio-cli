package backend.client;

import akka.actor.UntypedActor;


public class ClientSession extends UntypedActor {
    @Override
    public void onReceive(Object message) throws Exception {

    }

    public void setClientComponentdata(Integer componentId, String componentDataKey, String componentDataValue){

    }
}
