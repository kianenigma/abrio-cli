package backend;

/**
 * Created by Kian on 4/29/16.
 */
public class Delete {
    private String key ;

    public Delete(String Key) {
        this.key = Key;
    }

    public String key(){ return key ; }
}
