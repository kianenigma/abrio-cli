package backend;

/**
 * Created by Kian on 4/29/16.
 */
public class Get {
    private String key ;

    public Get(String Key) {
        this.key = Key;
    }

    public String key(){ return key ; }
}
