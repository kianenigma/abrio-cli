package ir.abrio.dev.sdk;

import akka.actor.*;
import akka.pattern.Patterns;
import akka.util.Timeout;
import backend.*;
import backend.client.ClientSession;
import backend.util.MessageChannel;
import ir.abrio.dev.protocol.AbrioProtocol;
import akka.dispatch.*;
import scala.concurrent.ExecutionContext;
import scala.concurrent.Future;
import scala.concurrent.Await;
import scala.concurrent.Promise;
import akka.util.Timeout;
import scala.concurrent.duration.Duration;


/**
 * AbrioLogic is main abstract class.
 * Implement this class
 */
public abstract class AbrioComponent extends UntypedActor {

    public PersistentDataHandler AbrioDataHandler ;

    public AbrioComponent() {
        System.out.println("Hi I am abrio component. I am created at " + getSelf().path().toString());
        AbrioDataHandler = new PersistentDataHandler(
                getContext()
                        .actorSelection(getSelf().path().parent().toString() + "/AbrioPersistentData" )
        ) ;
    }
    @Override
    public void onReceive(Object message) throws Exception {

        if (message instanceof EventPacket){
            receive(((EventPacket) message).msg(),
                    new Context(getSender(), ((EventPacket) message).session()));
        }
        else if(message instanceof ClientUpEvent){
            connectionEstablished(
                    new Context(getSender(),((ClientUpEvent) message).clientSession()));
        }
        else if(message instanceof ClientDownEvent){
            connectionClosed(
                    new Context(getSender() , ((ClientDownEvent) message).clientSession()));
        }
        else {
            // todo throw exception
            System.out.println("Invalid message received in AbrioComponent: "+message.getClass().getName());
        }
    }

    protected boolean authenticateUser(String username, String password, Context context){
        if(username.equals("arian") && password.equals("1234")){ //TODO need to implement database connection
            context.getSession().setClientComponentdata(id(), "authenticated", "true"); // maybe think this one through later
            return true;                                                                // to avoid using static hard coded key:value
        }else {
            return false;
        }
    }

    protected ActorRef createChannel(Context context){
        return context().actorOf(Props.create(MessageChannel.class));
    }

    protected void subscribeTo(ActorRef channel,ClientSession client){
        channel.tell(new SubscribeSession(client.self()),self());
    }

    protected void unsubscribeFrom(ActorRef channel,ClientSession client){
        channel.tell(new UnsubscribeSession(client.self()),self());
    }

    /**
     * This function will be called each time a message receive
     * @param message received message
     * @param context Context object contain state of incoming event
     */
    abstract public void receive(AbrioProtocol.EventWrapper message,Context context);

    /**
     * This function will be called each time a client join logic
     * @param context Context object contain state of incoming event
     */
    abstract public void connectionEstablished(Context context) ;

    /**
     * This function will be called each time a client disconnect from logic
     * @param context Context object contain state of incoming event
     */
    abstract public void connectionClosed(Context context) ;

    /**
     * @return id of component
     */
    abstract public Integer id();

    protected class Context{
        private ActorRef sender;
        private ClientSession session;
        public Context(ActorRef sender,ClientSession session){
            this.sender = sender;
            this.session = session;
        }
        /**
         * DO NOT override this function unless you know exactly what are you doing
         * @param message this message will be send to client
         */
        public void send(AbrioProtocol.EventWrapper message){
            sender.tell(new EventPacket(message,session,id()),getSelf());
        }

        public ClientSession getSession() {
            return session;
        }
    }

    /**
     * Singleton Component Data Handler Class
     * provides some wrappers around LogicPersistentData actor
     */
    public class PersistentDataHandler {

        private ActorSelection logicPDataActorRef ;

        private PersistentDataHandler(ActorSelection dataHandlerPath) {
            logicPDataActorRef = dataHandlerPath ;
        }


        public String getData(String key)  {
            // Default time out indicates how blocking could span .
            // 2s is probably more than enough if all components are on a single machine.
            Timeout timeout = new Timeout(Duration.create(2, "seconds"));
            Future<Object> future = Patterns.ask(logicPDataActorRef, new Get(key), timeout);
            String result = null;
            try {
                result = (String) Await.result(future, timeout.duration());
            } catch (Exception e) {
                e.printStackTrace();
            }

            return result ;
        }

        public void setData(String key , String payload) {
            logicPDataActorRef.tell(new Update(key, payload) , getSelf());
        }

        public void deleteData(String key) {
            logicPDataActorRef.tell(new Delete(key), getSelf());
        }

        public void flushData() {
            logicPDataActorRef.tell(new Flush() , getSelf());
        }
    }



}
